# ------------------------------------------------------------
# Import libraries
# ------------------------------------------------------------
# =====> Write your code here

# ------------------------------------------------------------
# Global variables
# ------------------------------------------------------------
# =====> Write your code here

# ------------------------------------------------------------
# Main program
# ------------------------------------------------------------

# Reverse printing of alphabet
# =====> Write your code here


# Convert a letter to its ASCII code
# =====> Write your code here


# Find the square root of a number to four decimal places
# =====> Write your code here


