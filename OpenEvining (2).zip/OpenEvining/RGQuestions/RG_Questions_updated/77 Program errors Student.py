array = ["M", "M", "M", "M", "F", "F", "M", "F", "M", "M"]
length = 0
count = 0
count2 = 0
index = 0
length = len (array)#gets the length of a 
while (index < length):
    if (array[index] == "F"):
        count = count + 1
    else:
        count2 = count2 + 1
    index = index + 1
print (index)
print (count2)
