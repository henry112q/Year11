import random
def Dice():
    Die1 = random.randint(0,6)
    Die2 = random.randint(0,6)
    Total = Die1+Die2
    print("You rolled a",Die1,"and a",Die2,"totalling",Total)
Dice()
