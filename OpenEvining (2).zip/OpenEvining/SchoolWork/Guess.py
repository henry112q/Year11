mysteryNumber = str(666)
correct = False

while (correct == False):
    number0 = False
    number1 = False
    number2 = False
    guess = str(input ("Enter a guess: "))
    for number in guess:
        if number in [mysteryNumber[0],mysteryNumber[1],mysteryNumber[2]]:
            numbersFound = True

    if mysteryNumber == guess:
        correct = True  

    if mysteryNumber[0] == guess[0]:
        number0 = True

    if mysteryNumber[1] == guess[1]:
        number1 = True    
    
    if mysteryNumber[2] == guess[2]:
        number2 = True


    print('found =', correct ,'number0 =', number0 ,'number1 =' ,number1 ,'number2 =', number2)