workertype = input("please enter F for full time and P for part time --> ").lower()
if workertype == "f":
    pay = int(input("How many full years have you worked "))*100
    if pay > 500:
        pay = 500
else:
    pay = int(input("please enter how many sets of 100 hours worked  "))*50
    if pay > 300:
        pay = 300

print(pay)