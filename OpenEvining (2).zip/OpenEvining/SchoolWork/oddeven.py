#Test if a number is even or odd
running = True
while running:
    Number = input("Enter Number: ")
    if Number == 'x' or Number == "X":
        running = False
        break
    Number = int(Number)
    if Number%2 == 0:
        print("Even")
    else:
        print("Odd")
