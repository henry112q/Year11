
# A subroutine to read a file and return a list of words
def read_file(filename):

  allWords = []

  with open(filename, "r") as file:

    for line in file:

      line = line.strip()
      lineWords = line.split(" ")

      for word in lineWords:
        allWords.append(word)

  return allWords


# A subroutine to count the number of times each word appears in a list,
# getting rid of any numbers or punctuation and ignoring capital letters,
# and return a dictionary where the keys are the words and the values are the counts
def count_words(allWordsList):

  counts = {}

  for word in allWordsList:

    standardised = ""

    for letter in word:

      # Only add letters if they are in the alphabet
      if letter.isalpha():
        letter = letter.lower()
        standardised += letter

    # Only add to the dictionary if it is a word
    if standardised.isalpha():

      if standardised not in counts.keys():
        counts[standardised] = 1
      else:
        counts[standardised] += 1

  return counts

# A subroutine to loop through the values in the dictionary
# and return the most used word and how many times it occurred
def find_max(allWordsDict):

  currentMaxCount = 0
  currentMax = ""

  for key, value in allWordsDict.items():

    if value > currentMaxCount:
      currentMax = key
      currentMaxCount = value

  return currentMax, currentMaxCount



# Main Program

# Read in and parse file
words = read_file("romeoAndJuliet.txt")

# Count each word in the file
countedWords = count_words(words)

# Get the most frequently used word and how many times it occurred
largest, largestCount = find_max(countedWords)

# Tell the user the number of unique words and the most frequently used word
print("There are",len(countedWords),"unique words recorded.")
print("The most frequently occurring word was \""+largest+"\" with",largestCount,"instances.")

# Let the user repeatedly enter a word to show the number of times it occurred, until they enter -1
word = input("Enter a word to show its frequency (type -1 to end): ").lower()

while word != "-1":

  # Use .get() with dictionaries to prevent an error when the key doesn't exist
  frequency = countedWords.get(word)

  # .get() returns None if the key doesn't exist
  if frequency != None:
    print("\""+ word + "\" appeared", frequency, "times.")
  else:
    print("Word was not found in this text.")

  word = input("Enter a word to show its frequency (type -1 to end): ").lower()
