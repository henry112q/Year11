import random
from turtle import *

# This code was written for the default IDLE
# screen size, so yours may look different.

def sun():
  pendown()
  pencolor("orange")
  pensize(3)
  fillcolor("yellow")
  begin_fill()
  circle(60)
  end_fill()
  pencolor("black")

def ground():
  pendown()
  fillcolor("brown")
  begin_fill()

  for i in range(2):
    fd(1200)
    rt(90)
    fd(320)
    rt(90)

  end_fill()


def sky(isNight):


  if isNight:
    print("It's nighttime")
    colour = "black"
  else:
    # Choose lightblue most of the time, but allow for other weather

    randomNum = random.randint(1,150)
    
    if randomNum > 50:
      print("It's a chilly Spring day")
      colour = "lightblue"
    elif 30 < randomNum <= 50:
      print("It's a blazing Summer day")
      colour = "aqua"
    elif 20 < randomNum <= 30:
      print("It's a bleak Winter day")
      colour = "grey"
    else:
      print("Look a sunset is starting!")
      colour = "pink"
    
  pendown()
  lt(90)
  fillcolor(colour)
  begin_fill()
  for i in range(2):
    fd(1000)
    rt(90)
    fd(1200)
    rt(90)
  end_fill()

def background_day():
  penup()
  
  goto(-500,-300)
  ground()
  
  sky(False)
  penup()
  goto(-250,250)
  sun()

def moon():
  pendown()
  fillcolor("grey")
  begin_fill()
  circle(45)
  end_fill()

def star():
  pendown()

  fillcolor("yellow")
  begin_fill()

  # Vary their rotation and size
  rotation = random.randint(0,180)
  rt(rotation)
  size = random.randint(2,7)

  for t in range(5):
    fd(size)
    rt(120)
    fd(size)
    rt(-48)
  end_fill()

  # undo the rotation
  lt(rotation)

def background_night():
  penup()
  goto(-500,-300)
  ground()

  sky(True)

  numberOfStars = random.randint(5,30)
  print("There are",numberOfStars,"stars visible in the sky")

  for s in range(numberOfStars):
    # Choose random coordinates for the stars
    randomX = random.randint(-400,400)
    randomY = random.randint(-250,400)

    penup()
    goto(randomX,randomY)
    star()
    pendown()

  penup()
  goto(300,250)
  moon()

def square_skyscraper(noOfFloors):
  pendown()
  pensize(5)

  fillcolor("grey")
  pencolor("purple")
  begin_fill()

  for i in range(noOfFloors):

    for j in range(4):
      fd(80)
      rt(90)
    fd(80)

  end_fill()

  # The code below adds the lightning rod and satellite dish on the top
  rt(90)
  fd(20)
  lt(90)
  pencolor("black")
  fd(40)

  pu()
  bk(40)
  rt(90)
  fd(40)
  fillcolor("black")
  begin_fill()
  circle(12)
  end_fill()


def triangle_skyscraper():
  pendown()
  lt(90)
  fillcolor("blue")
  pencolor("black")
  pensize(5)
  begin_fill()
  # Angles/ distances here are for an isosceles triangle
  rt(23)
  fd(540)
  rt(134)
  fd(540)
  rt(113)
  fd(420)
  rt(90)
  end_fill()

def small_building(userColour):
  pendown()
  lt(90)
  fillcolor(userColour)
  pencolor("pink")
  begin_fill()
  for i in range(2):
    fd(50)
    rt(90)
    fd(150)
    rt(90)
  end_fill()

  penup()
  rt(90)
  
# Main


noOfFloors = input("Enter the number of floors for a skyscraper: ")

# Ensure the input is valid
while noOfFloors.isdigit() == False or not(1<= int(noOfFloors) <= 15): 
  noOfFloors = input("Invalid. Reenter: ")

while True:
  try:
    buildingColour = input("What building colour would you like? ")
    # See if this colour will cause an error. If it doesn't, reset and break
    pencolor(buildingColour)
    pencolor("black")
    break
  except:
    print("This isn't a valid colour. Please try again.")
  

# This line speeds up the turtle
speed(0)

dayOrNight = random.randint(0,1)

if dayOrNight == 1:
  background_day()
else:
  background_night()

penup()

goto(-350, -300)
square_skyscraper(3)

lt(90)
goto(-250,-300)

square_skyscraper(int(noOfFloors))

goto(-100,-300)
small_building(buildingColour)

goto(100, -300)
triangle_skyscraper()






