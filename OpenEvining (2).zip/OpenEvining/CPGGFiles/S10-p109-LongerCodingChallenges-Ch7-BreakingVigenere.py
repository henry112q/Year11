"""This approach uses a brute force dictionary attack.
Since you know the words originated from the vigenereWords.txt file,
you can attempt to decrypt each word in the file with another word in the file.
The file is the dictionary and the attack is 'brute force' as it tries every possibility.

This approach works as Vigenere encryption is like an equation that you can rearrange.
Decrypting a ciphertext with its plaintext gives you the key used to encrypt it.

When you have two ciphertexts, and you know the plaintexts are in the file, you can
find a possible key by decrypting one ciphertext using one word in the file as the 'key'.
Then you can test this key out by decrypting the other ciphertext using it and seeing if the
result is a plaintext in the file.

As there are ~17000 words in the file, this program may take a minute or so to run.
"""

# The next 3 functions are reused from the previous challenge
def lookup_value(letter):

  alphabet = {"A":0,"B":1,"C":2,"D":3,"E":4,"F":5,"G":6,"H":7,"I":8,
  "J":9,"K":10,"L":11,"M":12,"N": 13,"O":14,"P":15,"Q":16,"R":17,"S":18,
  "T":19,"U":20,"V":21,"W":22,"X":23,"Y":24,"Z":25}

  return alphabet[letter]

def lookup_letter(value):

  alphabet = {0:"A",1:"B",2:"C",3:"D",4:"E",5:"F",6:"G",7:"H",8:"I",
              9:"J",10:"K",11:"L",12:"M",13:"N",14:"O",15:"P",16:"Q",
              17:"R",18:"S",19:"T",20:"U",21:"V",22:"W",23:"X",24:"Y",25:"Z"}

  return alphabet[value]

def decrypt(ciphertext, key):

  plaintext = ""
  
  for i in range(len(ciphertext)):

    ciphertextLetter = ciphertext[i]
    keyLetter = key[i]
    ciphertextValue = lookup_value(ciphertextLetter)
    keyValue = lookup_value(keyLetter)
    plaintextValue = (ciphertextValue - keyValue) % 26
    plaintextLetter = lookup_letter(plaintextValue)
    plaintext += plaintextLetter 

  return plaintext

# Main program

ciphertext1 = "CDAUXMCFE"
ciphertext2 = "VFQJTCQCN"

print("Loading the dictionary of words...")

# Load in the dictionary of words
words = []

with open("vigenereWords.txt", "r") as file:

  for line in file:

    line = line.strip()
    words.append(line)

print("Starting the brute forcing...")

# Start brute forcing - try and decrypt all words in the file
for word1 in words:

  # Create a candidate key, through trying to decrypt the first ciphertext with a word
  key = decrypt(ciphertext1, word1)

  # Use this candidate key to decrypt the second ciphertext
  result = decrypt(ciphertext2, key)

  for word2 in words:

    # If this result matches a word in the file, then you've broken the encryption!
    if result == word2:

      print("Plaintext 1 is:", word1)
      print("Plaintext 2 is:", word2)
      print("Key is:", key)
      break


#SPOILER WARNING - the plaintexts and the key are below.





























"""
The answers are as follows:
Plaintext 1 is: PROCEDURE
Plaintext 2 is: ITERATION
Key is: NMMSTJIOA
"""
      
  
