
# This takes in a string as input and returns an encoded version in standard RLE
def encode(uncompressed):

  compressed = ""

  # Initialise with the first character
  current = uncompressed[0]
  runLength = 1

  for i in range(1,len(uncompressed)):

    # Repeated characters constitute a 'run'
    if uncompressed[i] == current:
      runLength += 1

    # When a character doesn't match the run, reset it but add the runLength and the character to the RLE string
    else:
      compressed += str(runLength) + current
      runLength = 1
      current = uncompressed[i]

  # Ensure the last pair are added too
  compressed += str(runLength) + current

  return compressed

# This takes in a standard RLE string as input and returns the decoded version
def decode(compressed):

  uncompressed = ""
  frequency = ""
  value = ""
  
  for character in compressed:

    # If the character is a number, add it to a frequency string
    # This is needed as there could be multiple digits for the frequency
    if character.isdigit():
      frequency += character
    else:
      # When it hits a standard character, repeat the character the number of times held in the frequency string
      uncompressed += str(int(frequency) * character)

      # Reset the frequency string
      frequency = ""

  return uncompressed

# This function returns the number of bits saved or cost by running RLE on the argument string
def calculate_difference(uncompressed):

  compressed = encode(uncompressed)

  uncompressedBits = len(uncompressed) * 8
  compressedBits = len(compressed) * 8

  difference = uncompressedBits - compressedBits

  return difference

# This function ensures the 'compressed' string is in a RLE format the decode function can use
# Returns False if it can't be converted, or True and the standardised RLE if it can
def get_standard_RLE(compressed):

  if compressed[0].isdigit():
    # For RLE in the 1P1r1o1g format - already 'standard' so return
    return True, compressed
  
  elif compressed[0] == "(" and compressed[1].isdigit():
    # For RLE in the format (1,h),(2,i),(4,!)
    standard = ""
    frequency = ""

    for character in compressed:

      # Build up the frequency string - this is needed if it is more than one digit long
      if character.isdigit():
        frequency += character

      elif character not in [",","(",")"]:

        standard += frequency
        standard += character

        # Reset frequency now that the frequency has ended
        frequency = ""

    return True, standard      
    

  elif compressed[0] == "(" and compressed[1].isalpha():
    # For RLE in the format (h,1),(i,2),(!,4)

    standard = ""
    value = ""
    frequency = ""

    # The approach here is to delay adding the value until the next frequency is found
    for character in compressed:

      if character.isdigit() == False and character not in [",","(",")"]:

        standard += frequency + value
        value = character
        frequency = ""
        
      elif character.isdigit():
        frequency += character

    # Make sure to add the final frequency/ value pair
    standard += frequency + value
    
    return True, standard      
        
    
  else:
    # RLE not in the correct format, so return False
    return False, ""
    
# This saves toWrite to the filename file. 'mode' is used to append to the file name.
# True is returned if this worked, False if it didn't
def write_to_file(toWrite, filename, mode):
  try:
    
    with open(mode+"_"+filename, "w") as file:

      file.write(toWrite)

    return True

  except:
    return False

# This returns either the contents of the file as a string or False (if the reading failed)
def read_from_file(filename):

  try:
    with open(filename, "r") as file:

      fileContents = ""

      for line in file:

        # Remove \n and any leading/ trailing spaces as they will disrupt the RLE
        line = line.strip()
        fileContents += line

      return fileContents

  except:
    return False

# Main program

while True:

  print("Select an option for RLE conversions.")
  print("1. Encode or Decode text.")
  print("2. Calculate space saved.")
  print("3. Encode or Decode a file.")
  print("4. Quit.")

  option = input()

  # End only if Quit is selected
  if option == "4":
    break
  
  else:
    
    if option == "1":

      mode = input("Do you want to Encode or Decode? ").lower()
      
      if mode == "encode":

        text = input("What text do you want to use? ")
        print("\nEncoded: "+encode(text))
        
      elif mode == "decode":

        text = input("What text do you want to use? ")
        # Convert the input to standard RLE before decoding
        check = get_standard_RLE(text)

        if check[0] == False:
          print("\nInvalid RLE.")
        else:
          print("\nDecoded: "+decode(check[1]))
      else:
        print("\nInvalid mode - enter either Encode or Decode.")
      
    elif option == "2":

      text = input("What text do you want to use? ")

      savings = calculate_difference(text)

      if savings < 0:
        print("\nConverting to RLE would actually cost you",-savings,"bits.")
      else:
        print("\nConverting to RLE would save you",savings,"bits.")

    elif option == "3":

      mode = input("Do you want to Encode or Decode? ").lower()

      if mode == "encode":
        file = input("What file do you want to encode? ")

        # Read in text from file
        uncompressed = read_from_file(file)
        
        if uncompressed != False:
          if calculate_difference(uncompressed) < 0:
            print("\nThis wouldn't result in a saving so will not be encoded.")
          else:
            
            compressed = encode(uncompressed)

            hasWritten = write_to_file(compressed, file, "Encoded")

            if hasWritten:
              print("\nEncoded and written successfully.")
            else:
              print("\nError encountered.")
              
        else:
          print("\nError encountered in finding and reading the file.")

      elif mode == "decode":

        file = input("What file do you want to decode? ")

        compressed = read_from_file(file)

        if compressed != False:

          # Ensure it is in standard RLE
          check = get_standard_RLE(compressed)

          if check[0] == False:
            print("\nInvalid RLE. Please check the format of the file.")
          else:

            compressed = check[1]

            uncompressed = decode(compressed)
            
            hasWritten = write_to_file(uncompressed, file, "Decoded")

            if hasWritten:
              print("\nDecoded and written successfully.")
            else:
              print("\nError encountered.")

        else:
          print("\nError encountered in finding and reading the file.")
            

      else:
        print("\nInvalid selection.")
    
    else:
      print("\nInvalid selection.")

  print()

        
        
    
  

