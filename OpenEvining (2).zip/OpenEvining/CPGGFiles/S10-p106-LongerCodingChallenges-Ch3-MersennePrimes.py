"""
Like with all of the challenges in this section, there are a few different
ways to solve them. However, for this challenge, making your code
efficient is especially important to get the later Mersenne primes (as they're so big!).

Use the additional information given in the question to increase the efficiency
of your code if your current program is taking too long. 
"""

# The code below is one approach that may take a while to generate more than 8 Mersenne primes

# This function returns True if the candidate number is prime, False if it's not
def is_prime(candidate):

  # 1 and 2 are simple cases to check
  if candidate == 1:
    return False
  elif candidate == 2:
    return True

  # Check all possible factors of the number apart from 1 and itself
  for num in range(2, candidate):

    # If they divide cleanly, then num must be a factor and so the candidate can't be prime
    if candidate % num == 0:
      return False
      
  else:
    # If the loop ends naturally, the candidate must be prime
    return True

print("Printing out the Mersenne primes...")

# Testing different candidates for Mersenne primes using the function above.
# Stop when you find 10 (which may not happen in a reasonable time, since this isn't very efficient)

i = 1
numberFound = 0

while numberFound < 10:

  candidate = 2**i - 1

  if is_prime(candidate):
    print(candidate)
    numberFound += 1

  i += 1


"""
# The code from this line onwards is another approach that is likely to be much more efficient.
# You may need this algorithm to find the 8th, 9th, and 10th Mersenne primes given these are much bigger.

# Implementing the Lucas-Lehmer test
# P is the exponent to be tested
def LLT(P):

  # LLT only works if P is greater than 2, so include a case when it is 2
  if P == 2:
    return 2**P -1

  # Initialise 4
  s = 4

  # M is the candidate Mersenne prime to be tested
  M = 2**P - 1

  # Keep going until you reach P - 2
  for i in range(P - 2):

    s = ((s**2) - 2) % M

  # Once you have reached P - 2, check if s is 0.
  # If it is, then you've found a Mersenne prime.
  if s == 0:
    return 2**P - 1
  else:
    return False

print("Printing out the Mersenne primes...")

# This code calls the Lucas-Lehmer test on exponents (i) until there have been 10
i = 1
numberFound = 0

while numberFound < 10:

  result = LLT(i)
  
  if result != False:
    numberFound += 1
    print(result)

  i += 1
"""
