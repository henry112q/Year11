import random

# Load in and parse the file. Return a 2D list
def read_file(filename):

  players = []

  with open(filename, "r") as file:

    for line in file:

      line = line.strip()
      record = line.split(",")

      players.append(record)

  return players

# Write the players 2D list to a CSV-style text file
def write_to_file(filename, players):

  with open(filename, "w") as file:
    
    for player in players:

      if player != players[-1]:

        file.write(player[0] + "," + player[1] + "\n")

      else:
        file.write(player[0] + "," + player[1])


# See if the lottery numbers are in the file already. Return True if they are not.
def validate_numbers(numbers, players):

  for player in players:

    if numbers in player[1]:
      return False
  else:
    return True

"""
This function generates random lottery numbers. If isDraw is False, it is choosing
numbers for the player and so these should be unique in the file. If isDraw is True,
it is drawing the winning numbers.
"""
def generate_numbers(players, isDraw):

  # Return false if all combinations have been used up already!
  if len(players) == 10**5:
    return False
  
  while True:

    numbers = ""
    
    for i in range(5):

      if i != 4:

        numbers += str(random.randint(0,9)) + " "

      else:
        numbers += str(random.randint(0,9))

    if validate_numbers(numbers,players) and isDraw == False:
      return numbers
    elif isDraw:
      return numbers
      
  

# Main program

while True:

  # Parse and load in file
  players = read_file("lotteryDraw.txt")

  print("Welcome to the lottery manager. Select an option.")
  print("1. Register a ticket.")
  print("2. Draw a winner.")
  print("3. Calculate odds.")
  print("4. Quit.")

  option = input()

  # End only if Quit is selected
  if option == "4":
    break

  elif option == "1":

    # Check that the numbers of players hasn't exceeded the limit
    if len(players) == 10**5:
      print("No more tickets can be registed.")

    else:
      
      print("\n1. Provide the numbers.")
      print("2. Generate the numbers.")

      option = input()

      if option == "1":

        while True:

          numbers = ""

          for i in range(1,6):

            number = input("Enter number " + str(i) + ": ")

            # Validate the input
            while number.isdigit() == False or (int(number) < 0 or int(number) > 9):
              number = input("Enter number " + str(i) + ": ")

            if i < 5:
              numbers += number + " "
            else:
              numbers += number

          # If it's valid, leave the loop
          if validate_numbers(numbers, players):
            break
          else:
            print("These numbers exist already, enter again. ")

      elif option == "2":

        numbers = generate_numbers(players, False)

      # Leave the loop if the wrong option was selected
      else:
        break

      # Now that numbers have been entered/ generated, write these to the file
      name = input("Enter your name: ")

      newPlayer = [name, numbers]
      players.append(newPlayer)

      write_to_file("lotteryDraw.txt", players)

  elif option == "2":

    print("\n1. Draw only exact numbers.")
    print("2. Draw a random winner.\n")

    option = input()

    if option == "1":

      winningNumbers = generate_numbers(players, True)
      print("The winning Numbers are", winningNumbers)

      for player in players:
        # Check if there is a winner
        if player[1] == winningNumbers:
          print("The winner is",player[0])
          break
      else:
        print("No players had those numbers.")

    elif option == "2":

      # Choose a random item - could also use random.randint() with len() to do this
      winner = random.choice(players)

      print("The winner is",winner[0])

    else:

      print("\nInvalid selection.")
      

  elif option == "3":

    # Format percentages
    # 10**5 is because there are 10 options per digit, and there are 5 digits which all need to be correct
    drawOnlyExact =  round((1 / (10**5)) * 100,5)
    drawRandomWinner = round((1 / len(players) * 100),5)

    print("\nFor drawing exact numbers, the chance of winning is", str(drawOnlyExact) + "%")
    print("For drawing random winners, the chance of winning is", str(drawRandomWinner) + "%")           
        
  print()
  

