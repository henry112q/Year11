def encode(mess):
    """ Run length encoding - convert string from 'wwwwwwbbbb' til '6w4b'"""

    res = []
    old_val = mess[0]
    count = 0
    for char in mess:
        if char == old_val:
            count += 1
        else:
            res.append('%d%c' % (count, old_val))
            old_val = char
            count = 1
    res.append('%d%c' % (count, char))
    return ''.join(res)  # listen bliver returneret med .join() funktion = 6w4b og IKKE 6w 4b

def decode(mess):
    """Run length decoding - convert string from '2k3b' to 'kkbbb'"""
    res = []
    num = ''
    for char in mess:
        # IF character is an integer, add it to current num
        if char.isdigit():
            num += char
        else:
            # 'a'* int('3') = 'aaa' expand on this
            # after expanding num is set to empty
            res.append(char*int(num))
            num = ''
    return ''.join(res)



