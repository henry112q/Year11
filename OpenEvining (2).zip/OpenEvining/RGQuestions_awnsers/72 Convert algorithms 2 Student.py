# ------------------------------------------------------------
# Global variables
# ------------------------------------------------------------
# =====> Write your code here
userInput = 0
# ------------------------------------------------------------
# Main program
# ------------------------------------------------------------
# =====> Write your code here
# Get the user input

userInput = input("Please enter the current Voltage: ") # gets the user to input the current voltage

if userInput == 1: # If voltage is 1 the text below is displayed 
    print("Low voltage - Window is opaque")

elif userInput == 2:# If voltage is 2 the text below is displayed 
    print("Medium voltage - window is partially transparent")

elif userInput == 3:# If voltage is 3 the text below is displayed 
    print("High voltage - window is fully transparent")

else: # if userInput is not 1 2 or 3 the text below is run 
    print("Invalid input")
