#--------------------------------------------------------------------
# Constants
#--------------------------------------------------------------------
ON_ROLL = 3722          # Students enrolled in college

#--------------------------------------------------------------------
# Global variables
#--------------------------------------------------------------------
languageTable = ["French", "Italian", "Spanish", "Mandarin", "German"]
enrolmentNumbers = [366, 130, 494, 79, 243]
# =====> Write your code here
enrolmentPercernages = []
totalNumber = 0
totalPercentage = 0.0
#--------------------------------------------------------------------
# Main program
#--------------------------------------------------------------------
# =====> Write your code here
for enrolmentNumber in enrolmentNumbers:
    enrolmentPercernage = enrolmentNumber / ON_ROLL *100
    enrolmentPercernage = round(enrolmentPercernage,2)
    enrolmentPercernages.append(enrolmentPercernage)

for count in range(0,len(languageTable)):
    print(languageTable[count],enrolmentNumbers[count],enrolmentPercernages[count])

totalNumber = sum(enrolmentNumbers)
totalPercentage = totalNumber / ON_ROLL * 100
totalPercentage =  round(totalPercentage,2)
print("total for langauges is",totalNumber,totalPercentage)