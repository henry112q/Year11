# ------------------------------------------------------------
# Global variables
# ------------------------------------------------------------
varieties = ["lobster", "cuttlefish", "crab", "whelks",
           "scallops", "sea bass", "red mullet"]

# =====> Write your code here
likes = []
total = 0
outstring = ""
layout = "you like a total of {} varieties"
sorted = 0
# ------------------------------------------------------------
# Main program
# ------------------------------------------------------------
# =====> Write your code here
while sorted != 7:
    inputstr = "do you like ",varieties[sorted],"?"
    like = input(inputstr)
    like = like.upper()
    if like == "Y":
        likes.append(varieties[total])
        total += 1
    sorted += 1
outstring = layout.format(total)
for x in range (len(likes),0,-1):
    outstring = outstring, likes[0]
    likes.remove(x)
print(outstring)