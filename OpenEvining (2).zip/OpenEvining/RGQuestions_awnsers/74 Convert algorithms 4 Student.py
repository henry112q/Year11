# ------------------------------------------------------------
# Main program
# ------------------------------------------------------------
# =====> Write your code here

number1 = 1
while True:
    if number1 == 13:
        quit()
    else:
        print("times table for",number1)
        number2 = 1 
        while number2 != 13:
            print("Number1 times number2 is",number1*number2)
            number2 += 1

        number1 += 1