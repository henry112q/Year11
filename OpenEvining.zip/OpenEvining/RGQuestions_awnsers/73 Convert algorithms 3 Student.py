# ------------------------------------------------------------
# Import libraries
# ------------------------------------------------------------
# =====> Write your code here

import random

# ------------------------------------------------------------
# Global variables
# ------------------------------------------------------------
# =====> Write your code here

userInput = ""

number = 0

# ------------------------------------------------------------
# Main program
# ------------------------------------------------------------
# =====> Write your code here

while True: # this loops the code
    if userInput == "q": # this checks wether the user has entered the letter q 
        quit() # this ends the code

    number = random.randint(1,100) # asigns a random number to number  
    
    if number % 2 == 0: # this divides the number by 2 and checks for a reminder if it is 0 it equals
        print("the Number is even")
    
    else: # outputs the number is odd
        print("the number is odd")

    userInput = input("Press Q if you want to quit: ").lower() # this allows the user to enter q to quit and turns it into a lowercase character
    