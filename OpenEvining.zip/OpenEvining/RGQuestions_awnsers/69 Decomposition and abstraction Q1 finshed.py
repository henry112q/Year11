# ------------------------------------------------------------
# Global variables
# ------------------------------------------------------------
# Define all the needed variables
theName = ""
theAge = 0

# ------------------------------------------------------------
# Main program
# ------------------------------------------------------------
# Get the inputs required
theName = input("Please enter your name --> ")
theAge = int(input("Please enter your age --> "))
# Process the inputs and print outputs
if theAge < 3:
    print (theName, "is too young for school")
elif theAge > 19:
    print (theName, "is too old for school")
else:
    print (theName, "can go to school")

# Print the exit message
print("goodbye")