# ------------------------------------------------------------
# Global variables
# ------------------------------------------------------------
# Here is the data to store in the data structure
# The columns represent:
# Name, start of season, end of season, small, medium, large
#"Kyle of Tongue Pacific", "January", "December", 0, 1, 0
#"Loch Ryan Native", "September", "April", 0, 1, 1
#"Jersey Pacific", "January ", "December", 0, 1, 0
#"Fal Native Oysters", "September", "March", 1, 1, 1
#"Porthilly Pacific", "January", "December", 1, 1, 1
#"Helford Native", "September", "April", 1, 1, 1
#"Cornish Native", "September", "March", 1, 1, 1
#"Teignmouth Wild Pacific", "January", "December", 0, 1, 1
#"Poole Pacific", "January", "December", 1, 1, 1
#"Whistable Pacfic", "January", "December", 1, 1, 1
#"Maldon Wild Pacific", "January", "December", 0, 1, 1
#"Orford Pacific", "January", "December", 0, 1, 1

# =====> Create your data structure here


# ------------------------------------------------------------
# Subprograms
# ------------------------------------------------------------
# All oysters with a short season, i.e. not available all year round
def shortSeason ():
    # =====> Write your code here


# All oysters available in medium size only
def mediumOnly ():
    index = 0

    # =====> Write your code here


# ------------------------------------------------------------
# Main program
# ------------------------------------------------------------
shortSeason ()
mediumOnly ()
