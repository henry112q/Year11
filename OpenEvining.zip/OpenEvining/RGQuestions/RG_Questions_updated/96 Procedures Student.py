# ------------------------------------------------------------
# Global variables
# ------------------------------------------------------------
bookTable = [
    ["Goldilocks", 3.67, 22],
    ["Little Bo Peep", 2.98, 14],
    ["Baa Baa Black Sheep", 3.32, 34],
    ["Jack and Jill", 4.51, 16],
    ["Twinkle Twinkle Little Star", 3.47, 25],
    ["Row Row Row Your Boat", 3.02, 18],
    ["Humpty Dumpty", 2.74, 14],
    ["Five Little Speckled Frogs", 2.83, 23]]

# ------------------------------------------------------------
# Subprograms
# ------------------------------------------------------------
# Display headers
# =====> Write your code here


# Display each book
# =====> Write your code here


# ------------------------------------------------------------
# Main program
# ------------------------------------------------------------
# =====> Write your code here

