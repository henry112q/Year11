# ------------------------------------------------------------
# Global variables
# ------------------------------------------------------------
userTable = [["AAA34", 4860, "chocolate bourbon"],
             ["CAB98", 7101, "custard cream"],
             ["GUS21", 5975, "rich tea"],
             ["RAT67", 4173, "chocolate digestive"],
             ["TUM83", 6462, "shortbread"],
             ["TXA84", 1435, "oatmeal raisin"]]

# =====> Write your code here

# ------------------------------------------------------------
# Main program
# ------------------------------------------------------------
# =====> Write your code here
