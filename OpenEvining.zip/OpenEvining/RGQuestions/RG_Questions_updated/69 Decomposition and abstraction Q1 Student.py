# ------------------------------------------------------------
# Global variables
# ------------------------------------------------------------
# Define all the needed variables
theName = ""
theAge = 0

# ------------------------------------------------------------
# Main program
# ------------------------------------------------------------
# Get the inputs required

# Process the inputs and print outputs
if (                 ):
    print (theName, "is too young for school")
elif (                 ):
    print (theName, "is too old for school")
    print (theName, "can go to school")

# Print the exit message
