# Below 110Kg or below 10 years old - 10 Press Ups
# 110 to 200 Kg and between 10 and 50 years old - 40 Press Ups 
# Above 200Kg and between 10 and 50 years old - 30 Press Ups
# Above 200Kg and above 50 years old - 20 Press Ups


def exersice(age,wieght):
    if age < 10 or wieght < 110:
        print("ten push ups")
    elif age < 50 and wieght < 200:
        print("40 push ups")
    elif age < 50 and wieght < 200:
        print("30 push ups")
    elif (age > 50 and wieght >200):
        print("20 push ups")

age = int(input("please enter age --> "))
wieght = int(input("please enter wieght in kg --> "))

exersice(age,wieght)