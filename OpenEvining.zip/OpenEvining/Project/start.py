import random
import time
sanity = True
while sanity == True:
    num = random.randint(0,100)
    time.sleep(0.1)
    if num == 100:
        sanity = False

print("you have lost your sanity")