"""
There are a few ways to convert between bases, so if your
method is slightly different to the below then that's fine.
"""

def binary_to_denary(binary):

  # Validate to ensure input is in binary (as a string)
  while True:
    for digit in binary:
      if digit != "0" and digit != "1":
        # Give the user another chance to reenter the binary
        binary = input("Enter just zeros and ones: ")
        break
    else:
      # If the for loop ends naturally, it must be valid so break
      # out of the while loop
      break        

  exponent = 0
  denary = 0

  # Start on the right of the binary string and move right to left
  for i in range(len(binary)-1,-1,-1):

    # Work out the place value at that point
    placeValue = 2 ** exponent

    # Multiply the place value with the digit at that point
    denary += placeValue * int(binary[i])
    exponent += 1

  # As the validation may mean the binary value has changed, return both
  return binary, str(denary)

def denary_to_binary(denary):

  digit = 0
  binary = ""
  denary = int(denary)

  placeValue = 1

  # Calculate the largest place value needed
  # These are the powers of 2 (1, 2, 4, 8, 16, etc)
  while (placeValue * 2) <= denary:
    placeValue *= 2

  # remainder will keep track of what's left as you repeatedly divide by placeValue
  remainder = denary

  # Divide each placeValue to find the remainder
  while placeValue >= 1:

    # Divide and round down - quotient will always be either 0 or 1.
    quotient = int(remainder / placeValue)
    binary += str(quotient)

    # The remainder of the division is used for the next stage
    remainder = remainder % placeValue

    # Halve the place value for the next iteration, e.g. from 64 to 32
    placeValue = placeValue / 2

  return binary

# Main Program

# Keep repeating the options until the user Quits
while True:

  print("Select an option.")
  print("1. Denary to Binary.")
  print("2. Binary to Denary.")
  print("3. Quit.")

  option = input()

  if option == "3":
    break

  # If they enter something other than 1 or 2 it's not valid.
  elif option not in "12":
    print("Invalid selection, try again.\n")
    
  else:
    
    # Validate, call, and then format the results
    
    number = input("Enter a number: ")

    while number.isdigit() == False:
      number = input("Enter a number: ")

    if option == "1":
      result = denary_to_binary(number)
      print()
      print(number,"in binary is",result,"\n")
      
    elif option == "2":
      number, result = binary_to_denary(number)
      print()
      print(number,"in denary is",result,"\n")
      
    


    
