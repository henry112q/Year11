import random

# Helper function to convert the letter to its code
def lookup_value(letter):

  alphabet = {"A":0,"B":1,"C":2,"D":3,"E":4,"F":5,"G":6,"H":7,"I":8,
  "J":9,"K":10,"L":11,"M":12,"N": 13,"O":14,"P":15,"Q":16,"R":17,"S":18,
  "T":19,"U":20,"V":21,"W":22,"X":23,"Y":24,"Z":25}

  return alphabet[letter]

# Helper function to convert the code to its letter
def lookup_letter(value):

  alphabet = {0:"A",1:"B",2:"C",3:"D",4:"E",5:"F",6:"G",7:"H",8:"I",
              9:"J",10:"K",11:"L",12:"M",13:"N",14:"O",15:"P",16:"Q",
              17:"R",18:"S",19:"T",20:"U",21:"V",22:"W",23:"X",24:"Y",25:"Z"}

  return alphabet[value]
    
# Return the encrypted plaintext (the ciphertext)
def encrypt(plaintext, key):

  ciphertext = ""

  # For each letter in the plaintext
  for i in range(len(plaintext)):

    # Look up the value of these letters
    plaintextLetter = plaintext[i]
    keyLetter = key[i]
    
    plaintextValue = lookup_value(plaintextLetter)
    keyValue = lookup_value(keyLetter)

    # Find the ciphertext value - using MOD deals with the wraparound overflow
    ciphertextValue = (plaintextValue + keyValue) % 26

    # Look up the letter which corresponds to this value
    ciphertextLetter = lookup_letter(ciphertextValue)

    # Add to the ciphertext
    ciphertext += ciphertextLetter 

  return ciphertext

# Return the decrypted ciphertext (the plaintext)
def decrypt(ciphertext, key):

  plaintext = ""
  
  for i in range(len(ciphertext)):

    ciphertextLetter = ciphertext[i]
    keyLetter = key[i]
    
    ciphertextValue = lookup_value(ciphertextLetter)
    keyValue = lookup_value(keyLetter)

    # For the reverse process, subtract
    plaintextValue = (ciphertextValue - keyValue) % 26

    plaintextLetter = lookup_letter(plaintextValue)

    plaintext += plaintextLetter 

  return plaintext

# Use the random module to generate a random key the same length as the plaintext
def generate_key(plaintext):

  key = ""

  for i in range(len(plaintext)):

    keyLetter = lookup_letter(random.randint(0,25))
    key += keyLetter

  return key

# Main program
while True:

  print("Select an option.")
  print("1. Encrypt.")
  print("2. Decrypt.")
  print("3. Quit.")

  option = input()

  if option == "3":
    break

  elif option == "1":

    plaintext = input("What would you like to encrypt? ")

    # Validate the plaintext - should only be alphabetical characters
    while plaintext.isalpha() == False:
      plaintext = input("Invalid. What would you like to encrypt? ")

    plaintext = plaintext.upper()

    keyOption = input("Enter P to provide a key or G to generate a key for you: ").lower()

    while keyOption not in ["p","g"]:
      keyOption = input("Invalid. Enter P to provide a key or G to generate a key for you: ")

    key = ""

    if keyOption == "p":

      key = input("Enter your key: ")

      # Validate the key - should be alphabetical and the same length as the plaintext
      while key.isalpha() == False or len(key) != len(plaintext):

        key = input("Invalid. Enter your key: ")

      key = key.upper()

    else:
       key = generate_key(plaintext)

    ciphertext = encrypt(plaintext, key)

    print("\nPlaintext: ", plaintext)
    print("Key: ", key)
    print("Ciphertext: ", ciphertext)
    print()

  elif option == "2":

    ciphertext = input("What would you like to decrypt? ")

    while ciphertext.isalpha() == False:
      ciphertext = input("Invalid. What would you like to decrypt? ")
  
    ciphertext = ciphertext.upper()

    key = input("What is the key? ")

    while key.isalpha() == False or len(key) != len(ciphertext):

      key = input("Invalid. Enter your key: ")

    key = key.upper()

    plaintext = decrypt(ciphertext, key)

    print("\nPlaintext: ", plaintext)
    print("Key: ", key)
    print("Ciphertext: ", ciphertext)
    print()

  else:
    print("Invalid Selection.")
