import random

# This function returns a word to be used, depending on what difficulty the user opts for
def choose_word():

  with open("dictionary.txt","r") as file:

    allWords = file.readlines()

  difficulty = input("What difficulty do you want to play? Easy (E), Medium (M), or Hard (H)? ").upper()

  # Validate this input - it needs to be one of the 3 options
  while difficulty not in ["E","M","H"]:
    difficulty = input("What difficulty do you want to play? Easy (E), Medium (M), or Hard (H)? ").upper()

  # Keep choosing a word until one meets the criteria
  while True:
    randomIndex = random.randint(0,len(allWords)-1)
    randomChoice = allWords[randomIndex].strip().lower()

    if difficulty == "E" and len(randomChoice) <= 5:
      break
    elif difficulty == "M" and len(randomChoice) <= 10 and len(randomChoice) > 5:
      break
    elif difficulty == "H" and len(randomChoice) >= 11:
      break

  return randomChoice

# Show the main display - underscores are replaced by correctly guessed letters
# lettersToReveal and lettersGuessed are both list parameters
def generate_letters(word, lettersToReveal, lettersGuessed):

  obfuscated = ""

  for letter in word:

    # If the letter has been guessed, show it
    if letter in lettersToReveal:
      obfuscated += (letter + " ")

    # Otherwise, show the hyphen
    else:
      obfuscated += "_ "

  # Join the list into a space-separated string so it can be displayed
  alreadyGuessed = " ".join(lettersGuessed)

  # Only show the letters incorrectly guessed if there are some!
  if len(alreadyGuessed) == 0:
    return obfuscated + "\n"
  else:
    return obfuscated+"\tAlready guessed: "+alreadyGuessed+"\n"

# This function builds up the Snowman depending on how many guesses were made
def generate_snowman(guesses):
    
  snowman = []

  if guesses >= 1:
    bottomSnowball = "  (       )" + "\n" +"   \'-----\'"
    snowman.append(bottomSnowball)

  if guesses >= 2:
    middleSnowball = "   (     )"
    snowman.insert(0,middleSnowball)
          
  if guesses >= 3:

    headSnowball = "    (   )"
    snowman.insert(0,headSnowball)

  if guesses >= 4:
    # Replace headSnowball with version with face
    snowman[0] = "    ('v')"

  if guesses >= 5:
    # Replace middle snowball with version with branches and button
    snowman[1] = "--<(  .  )>--"
    snowman[2] = "  (   .   )" + "\n" + "   \'-----\'"

  if guesses >= 6:

    topHat = "     ___" + "\n" + "   _|___|_"
    snowman.insert(0,topHat)

  # A list has been used to support this process, but now return it as a string
  return "\n".join(snowman)
  

# The main program

print("Welcome to Snowball!\n")

# Receive a random word from the dictionary text file
word = choose_word()

print("\nLet's get started...\n")

print(generate_letters(word, "", []))

tries = 0
guessedWrong = []
guessedCorrect = []

while tries < 6:

  guess = input("Make a guess: ").lower()

  # Check this guess hasn't been made before
  while guess in guessedWrong or guess in guessedCorrect:
    guess = input("You guessed that before. Make another guess: ").lower()

  # Ensure that no spaces, numbers, or punctuation are entered
  while guess.isalpha() == False:
    guess = input("You input must be a letter or word. Make another guess: ")
  
  if guess not in word:

    # Only retain incorrect letters - words are either totally correct or wrong
    if len(guess) == 1:
      guessedWrong.append(guess)
      
    tries += 1
    
  else:

    if guess == word:
      print("You've won!")
      break
    else:
      guessedCorrect.append(guess)

  lettersToShow = generate_letters(word, guessedCorrect, guessedWrong)

  # Before displaying text - check to see if the user has won
  if "_" not in lettersToShow:
    print(lettersToShow)
    print("You've won!")
    break
  else:
    # If the user hasn't won, show the display
    print(lettersToShow)
    print(generate_snowman(tries))

else:
  # When the tries run out, the user has lost
  print("You lose. The word was \""+word + "\".")
  
print("That concludes our game of Snowball. Goodbye!")

  
